package ExceptionHandling;

public class ArrayIndexOutOfBoundsExceptionExample {

}
